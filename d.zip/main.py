import object as ob
import database as db
import yaml

from utils import *
from PyQt5.QtWidgets import *
import sys


if __name__ == '__main__':

    # should they be out of main?!
    with open("config.yml", "r") as ymlfile:
        cfg = yaml.safe_load(ymlfile)

    database_name = cfg['database']['database_name']
    user = cfg['database']['user']
    password = cfg['database']['password']
    host = cfg['database']['host']
    port = cfg['database']['port']
    schemas = cfg['database']['columns']

    AirlineTicketSelling_db = db.DataBase(
        database_name, user, password, host, port, schemas)
    AirlineTicketSelling_db.connect()

    # print(AirlineTicketSelling_db.get('Customer'))

    print(f'\x1b[0;37;40m' + '\nWindow Openned.')

    class Window(QWidget):

        def __init__(self):
            QWidget.__init__(self)
            layout = QGridLayout()
            self.setLayout(layout)
            label1 = QLabel("Widget in Tab 1.")
            tabwidget = QTabWidget()
            for t in AirlineTicketSelling_db.schemas:
                label = QLabel(f'label_{t}')
                tabwidget.addTab(label, t)

            layout.addWidget(tabwidget, 0, 0)

    app = QApplication(sys.argv)
    screen = Window()
    screen.setFixedWidth(1000)
    screen.setFixedHeight(600)
    screen.show()
    sys.exit(app.exec_())

    t = ob.TravelAgency('testName201', 'testAddr1120', '23456789087')
    AirlineTicketSelling_db.insert(t)
    g = AirlineTicketSelling_db.get('travelagency')
    print(g)
