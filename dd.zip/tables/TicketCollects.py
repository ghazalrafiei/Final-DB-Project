class TicketCollects:
    def __init__(
            self,
            flight_time,
            destination,
            source,
            ticket_id,
            price,
            tclass,
            airline,
            website_address,
            travel_agency_name):
        self.flight_time = flight_time
        self.destination = destination
        self.source = source
        self.ticket_id = ticket_id
        self.price = price
        self.tclass = tclass
        self.airline = airline
        self.website_address = website_address
        self.travel_agency_name = travel_agency_name

