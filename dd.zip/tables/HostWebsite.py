class HostWebsite:
    def __init__(self, website_address):
        self.website_address = website_address
